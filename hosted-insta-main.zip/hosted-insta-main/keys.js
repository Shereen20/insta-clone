module.exports = {
    mongoUrl: "mongodb+srv://srikantshreya:80UtrzPGmjBfPb4Q@cluster0.mitoefw.mongodb.net/?retryWrites=true&w=majority",
    Jwt_secret: "faslkfocvneofu"

};